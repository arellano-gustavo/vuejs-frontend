<template>
  <div style="text-align: center;">
    <h1>Kebblar Capital Trading Interface</h1>
  </div>
</template>

